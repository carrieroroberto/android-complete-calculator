/*
Roberto Carriero 5Di
Esercitazione di laboratorio - TPSIT
Calcolatrice
 */

package com.example.calcolatrice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Collections;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    // attributes declaration
    private Button zeroBtn, oneBtn, twoBtn, threeBtn, fourBtn, fiveBtn, sixBtn, sevenBtn, eightBtn, nineBtn, pointBtn, addBtn, subtractBtn, multiplyBtn, divideBtn, resultBtn, powerBtn, binaryBtn, bracketsBtn, cancelBtn, retMemBtn, memBtn, cancMemBtn;
    private TextView result, expression;
    private String expressionValue, mem;
    private boolean locked = true; // flag che indica se l'ultimo valore inserito è un operatore
    private boolean point = false; // flag che indica se è stato inserito il punto
    private boolean negative = false; // flag che indica se è stato inserito un esponente negativo
    private boolean parenthesis = false; // flag che indica se è stata aperta una parentesi

    private String binary(String value)
    {
        // prelevo la parte intera del numero
        int intPart = Integer.parseInt(value.split("\\.")[0]);

        // converto il numero in binario e lo salvo in una stringa
        String intPartBin = Integer.toBinaryString(intPart).toString();

        // se è un numero decimale
        if(value.contains("."))
        {
            // prelevo la parte decimale
            double decPart = Double.parseDouble("0." + value.split("\\.")[1]);
            String decPartBin = "";

            // per un massimo di 5 cifre decimali eseguo l'algoritmo per calcolare il numero binario salvandolo in una stringa
            for(int i=0; i<5; i++)
            {
                if(decPart * 2 >= 1)
                {
                    decPartBin += "1";
                    decPart *= 2;
                    decPart -= 1;
                }
                else
                {
                    decPartBin += "0";
                    decPart *= 2;
                }
            }

            // ritorno la stringa con la parte intera e la parte decimale
            return intPartBin + "." + decPartBin;
        }
        else
        {
            // ritorno esclusivamente la parte intera
            return intPartBin;
        }
    }

    private String resolve(String expression)
    {
        // ricorsione che risolve prima le parentesi
        while(expression.contains("(") && expression.charAt(expression.indexOf("(") + 1) != '-')
        {
            // estraggo il contenuto della parentesi
            String tempParenthesis = expression.substring(expression.indexOf("(") + 1, expression.indexOf(")"));
            String res = "";
            // se è un'espressione
            if(tempParenthesis.contains("^") || tempParenthesis.contains("/") || tempParenthesis.contains("*") || tempParenthesis.contains("+") || tempParenthesis.contains("-"))
            {
                // calcolo il risultato della parentesi
                res = resolve(tempParenthesis);
            }
            // se è un singolo valore
            else
            {
                // il risultato è uguale al valore all'interno della parentesi
                res = tempParenthesis;
            }

            // sostituisco alla parentesi nell'espressione il risultato
            expression = expression.replace("(" + tempParenthesis + ")", res);
        }

        // array con i simboli che hanno priorità maggiore
        char priority[] = {'^', '/', '*'};

        // vector che conterrano gli operandi e gli operatori
        Vector operands = new Vector();
        Vector operators = new Vector();
        double temp = 0;

        String original = expression;

        // sostituisco i simboli grafici con i relativi operatori matematici e rimuovo i simboli in eccesso
        expression = expression.replaceAll("÷", "/").replaceAll("×", "*").replaceAll("[()]", "").replaceAll("[\\^][-]", "^");

        // riempo il vector degli operatori estraendoli in ordine dall'espressione passata
        for(int i=0; i<expression.length(); i++)
        {
            if(expression.charAt(i) == '^' || expression.charAt(i) == '/' || expression.charAt(i) == '*' || expression.charAt(i) == '+' || expression.charAt(i) == '-')
            {
                operators.add(expression.charAt(i));
            }
        }

        // riempo il vector degli operandi estraendoli in ordine dall'espressione passata e rimuovendo le parentesi se presenti
        Collections.addAll(operands, expression.split("[\\^/*+-]"));

        // se non ci sono operatori ritorno lo stesso numero inserito
        if(operators.size() == 0)
        {
            return expressionValue;
        }
        else
        {
            // se l'espressione inizia con un numero negativo
            if(original.charAt(0) == '-')
            {
                // rimuovo la cella vuota iniziale
                operands.remove(0);

                // modifico il valore rendendolo negativo
                String negativeValue = "-" + operands.elementAt(0).toString();

                // imposto il nuovo valore
                operands.setElementAt(negativeValue, 0);

                operators.remove(0);
            }

            // effettuo prima tutte le potenze, poi le divisioni e le moltiplicazioni
            for(int i=0; i<priority.length; i++)
            {
                while(operators.contains(priority[i]))
                {
                    int index = operators.indexOf(priority[i]);
                    double op1 = Double.parseDouble(operands.elementAt(index).toString().replaceAll(",", "."));
                    double op2 = Double.parseDouble(operands.elementAt(index+1).toString().replaceAll(",", "."));
                    switch(priority[i])
                    {
                        case '^':
                            // verifico se l'esponente è negativo
                            if(original.contains("(-" + String.format("%.0f", op2) + ")"))
                            {
                                op2 *= -1;
                            }
                            // se esponente pari e segno negativo diventa positivo
                            if((int) op2 % 2 == 0 && operators.size() > 1 && (char) operators.elementAt(index - 1) == '-')
                            {
                                operators.setElementAt('+', index - 1);
                            }
                            temp = Math.pow(op1, op2);
                            break;
                        case '/':
                            if(op2 != 0)
                            {
                                temp = op1 / op2;
                            }
                            else
                            {
                                return "Impossibile";
                            }
                            break;
                        case '*':
                            temp = op1 * op2;
                            break;
                    }
                    operands.setElementAt(String.format("%.2f", temp).replaceAll(",", "."), index);
                    operands.remove(index+1);
                    operators.remove(index);
                }
            }

            // successivamente eseguo, nell'ordine in cui si presentano, addizioni e sottrazioni
            while(operands.size() > 1)
            {
                double op1 = Double.parseDouble(operands.elementAt(0).toString().replaceAll(",", "."));
                double op2 = Double.parseDouble(operands.elementAt(1).toString().replaceAll(",", "."));
                switch((char) operators.elementAt(0))
                {
                    case '+':
                        temp = op1 + op2;
                        break;
                    case '-':
                        temp = op1 - op2;
                        break;
                }
                operands.setElementAt(String.format("%.2f", temp).replaceAll(",", "."), 0);
                operands.remove(1);
                operators.remove(0);
            }

            // acquisisco il risultato per verificare se è intero o decimale
            String result = operands.elementAt(0).toString();

            //se intero ritorno il valore senza i decimali altrimenti ritorno il numero decimale completo
            if(result.split("\\.")[1].toString().equals("00"))
            {
                return result.split("\\.")[0].toString();
            }
            else
            {
                return result;
            }
        }
    }

    private void calculate(String value)
    {
        // verifico la validità dei valori passati e costruisco, man mano, l'espressione completa
        switch(value)
        {
            // memorizzo il risultato
            case "m+":
                if(!expressionValue.isEmpty())
                {
                    if(!locked && !parenthesis && expressionValue.charAt(expressionValue.length() - 1) != '.')
                    {
                        mem = resolve(expressionValue);
                    }
                    else
                    {
                        result.setText("Non valido");
                    }
                }
                break;

            // cancello la memoria
            case "m-":
                mem = "";
                break;

            // ritorno la memoria
            case "rm":
                if(locked)
                {
                    expressionValue = expressionValue.concat(mem);
                    expression.setText(expressionValue);
                    locked = false;
                    parenthesis = false;
                    point = false;
                    negative = false;
                }
                break;
            case "+":
            case "×":
            case "÷":
            case "-":
                    if(expressionValue.toString().isEmpty() && value.equals("-"))
                    {
                        expressionValue = expressionValue.concat(value);
                    }
                    else  if(!locked)
                    {
                        if(negative)
                        {
                            expressionValue = expressionValue.concat(")" + value);
                            negative = false;
                        }
                        else
                        {
                            expressionValue = expressionValue.concat(value);
                        }
                        if(point)
                        {
                            point = false;
                        }
                        locked = true;
                    }
                    else if(value.equals("-") && expressionValue.contains("^") && expressionValue.charAt(expressionValue.length() - 1) == '^')
                    {
                        expressionValue = expressionValue.concat("(" + value);
                        negative = true;
                    }
                break;
            case "^":
                if(!locked) {
                    expressionValue = expressionValue.concat(value);
                    locked = true;
                    point = false;
                }
                break;
            case ".":
                if(expressionValue.toString().isEmpty())
                {
                    expressionValue = expressionValue.concat("0" + value);
                    point = true;
                    locked = true;
                }
                else if(!locked && !point && expressionValue.charAt(expressionValue.length() - 1) != ')')
                {
                    expressionValue = expressionValue.concat(value);
                    locked = true;
                    point = true;
                }
                break;
            case "0":
                if(!expressionValue.toString().isEmpty())
                {
                    expressionValue = expressionValue.concat(value);
                    locked = false;
                }
                break;
            default:
                if(expressionValue.toString().isEmpty() || expressionValue.charAt(expressionValue.length() - 1) != ')')
                {
                    expressionValue = expressionValue.concat(value);
                    locked = false;
                }
                break;
            case "=":
                // chiamata al metodo resolve che effettua il calcolo dell'espressione, poi visualizzo il risultato
                if(!locked)
                {
                    if(negative)
                    {
                        expressionValue = expressionValue.concat(")");
                        negative = false;
                    }
                    else if(parenthesis)
                    {
                        expressionValue = expressionValue.concat(")");
                        parenthesis = false;
                    }
                    result.setText("= " + resolve(expressionValue));
                }
                break;
            case "p":
                if(!parenthesis)
                {
                    if(expressionValue.isEmpty() || locked)
                    {
                        expressionValue = expressionValue.concat("(");
                        parenthesis = true;
                    }
                }
                else
                {
                    if(!locked && expressionValue.charAt(expressionValue.length() - 1) != '(' || expressionValue.charAt(expressionValue.length() - 1) == ')')
                    {
                        expressionValue = expressionValue.concat(")");
                        parenthesis = false;
                        locked = false;
                    }
                }
                break;
            case "b":
                if(!locked)
                {
                    result.setText("= " + binary(resolve(expressionValue)));
                }
                break;

            // cancello l'ultimo carattere se premuto brevemente
            case "c":
                if(!expressionValue.isEmpty())
                {
                    String lastChar = expressionValue.substring(expressionValue.length()-1, expressionValue.length());
                    expressionValue = expressionValue.substring(0, expressionValue.length()-1);
                    if(lastChar.matches("\\."))
                    {
                        point = false;
                    }
                    else if(lastChar.matches("\\)"))
                    {
                        parenthesis = true;
                    }
                    else if(lastChar.matches("\\("))
                    {
                        parenthesis = false;
                    }
                    else
                    {
                        locked = false;
                    }
                    result.setText("");
                }
                else
                {
                    locked = true;
                    point = false;
                    negative = false;
                    parenthesis = false;
                }
                break;

            // cancello l'intera espressione se premuto più a lungo
            case "l":
                expressionValue = "";
                expression.setText(expressionValue);
                result.setText("");
                locked = true;
                point = false;
                negative = false;
                parenthesis = false;
                break;
        }
        if(expressionValue.toString().isEmpty())
        {
            expression.setText("0");
        }
        else
        {
            expression.setText(expressionValue);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // attributi
        zeroBtn = findViewById(R.id.zeroBtn);
        oneBtn = findViewById(R.id.oneBtn);
        twoBtn = findViewById(R.id.twoBtn);
        threeBtn = findViewById(R.id.threeBtn);
        fourBtn = findViewById(R.id.fourBtn);
        fiveBtn = findViewById(R.id.fiveBtn);
        sixBtn = findViewById(R.id.sixBtn);
        sevenBtn = findViewById(R.id.sevenBtn);
        eightBtn = findViewById(R.id.eightBtn);
        nineBtn = findViewById(R.id.nineBtn);
        pointBtn = findViewById(R.id.pointBtn);
        addBtn = findViewById(R.id.addBtn);
        subtractBtn = findViewById(R.id.subtractBtn);
        multiplyBtn = findViewById(R.id.multiplyBtn);
        divideBtn = findViewById(R.id.divideBtn);
        resultBtn = findViewById(R.id.resultBtn);
        powerBtn = findViewById(R.id.powerBtn);
        binaryBtn = findViewById(R.id.binaryBtn);
        bracketsBtn = findViewById(R.id.bracketsBtn);
        cancelBtn = findViewById(R.id.cancelBtn);
        memBtn = findViewById(R.id.memBtn);
        retMemBtn = findViewById(R.id.retMem);
        cancMemBtn = findViewById(R.id.cancMem);
        result = findViewById(R.id.result);
        expression = findViewById(R.id.expression);
        expressionValue = "";
        mem = "";
        expression.setMovementMethod(new ScrollingMovementMethod()); // scroller della TextView

        // imposto valori iniziali delle TextView
        result.setText("");
        expression.setText("0");

        // imposto i listener del click per ogni button passandone il valore alla funzione che gestisce la calcolatrice
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("c");
            }
        });

        zeroBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("0");
            }
        });

        oneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("1");
            }
        });

        twoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("2");
            }
        });

        threeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("3");
            }
        });

        fourBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("4");
            }
        });

        fiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("5");
            }
        });

        sixBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("6");
            }
        });

        sevenBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("7");
            }
        });

        eightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("8");
            }
        });

        nineBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("9");
            }
        });

        pointBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate(".");
            }
        });

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("+");
            }
        });

        subtractBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("-");
            }
        });

        multiplyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("×");
            }
        });

        divideBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("÷");
            }
        });

        powerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("^");
            }
        });

        binaryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("b");
            }
        });

        bracketsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("p");
            }
        });

        resultBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("=");
            }
        });

        memBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("m+");
            }
        });

        retMemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("rm");
            }
        });

        cancMemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate("m-");
            }
        });

        cancelBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                calculate("l");
                return true;
            }
        });
    }
}